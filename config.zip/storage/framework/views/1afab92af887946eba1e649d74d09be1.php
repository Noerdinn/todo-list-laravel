<?php $__env->startSection('title', 'My Tasks'); ?>
<?php $__env->startSection('content'); ?>

    <div
        class=" p-6 h-full scrollbar-thin scrollbar-thumb-black  scrollbar-track-transparent scrollbar-thumb-rounded-full container-pattern">
        <div
            class="grid md:grid-rows-[auto_1fr] grid-rows-[min-content_1fr] grid-cols-2 md:gap-4 gap-6 font-MadeforText h-full">
            <div class="row-start-1 h-min">
                <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div class="md:col-span-4">
                        <!-- Modal toggle -->
                        <button data-modal-target="crud-modal" data-modal-toggle="crud-modal"
                            class="block p-2 rounded-xl border-black shadow-[0px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-y-[4px] hover:shadow-none transition-all border-2 font-medium md:text-base text-sm w-full text-white bg-[#3A66B1] hover:bg-[#224E7D]"
                            type="button">
                            Create Task
                        </button>



                    </div>
                    
                </div>
                <!-- Main modal untuk create task -->
                <?php if (isset($component)) { $__componentOriginal3f0093379cf18d63bb75a5dc00a95612 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f0093379cf18d63bb75a5dc00a95612 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f0093379cf18d63bb75a5dc00a95612)): ?>
<?php $attributes = $__attributesOriginal3f0093379cf18d63bb75a5dc00a95612; ?>
<?php unset($__attributesOriginal3f0093379cf18d63bb75a5dc00a95612); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f0093379cf18d63bb75a5dc00a95612)): ?>
<?php $component = $__componentOriginal3f0093379cf18d63bb75a5dc00a95612; ?>
<?php unset($__componentOriginal3f0093379cf18d63bb75a5dc00a95612); ?>
<?php endif; ?>
            </div>


            <div 
                class="row-start-2 min-h-[60vh] max-h-[calc(100vh-185px)] md:col-span-1 col-span-full overflow-y-auto scrollbar-thin scrollbar-thumb-black scrollbar-track-transparent scrollbar-thumb-rounded-full p-6 border-2 rounded-lg border-black shadow-[0px_6px_0px_0px_rgba(0,0,0,1)] me-0 mb-0 md:me-2 md:mb-2 bg-white">
                <div class="flex mb-3">
                    <p class="md:text-xl text-lg font-medium me-2">Task</p>
                </div>
                <div>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div data-task-id="<?php echo e($task->id); ?>" onclick="showDetailTask(<?php echo e($task->id); ?>)"
                            class="task-item flex
                            justify-between py-2 px-4 mb-5 border-2 rounded-lg border-black transition-all 
                            shadow-[0px_4px_0px_0px_rgba(0,0,0,1)] overflow-x-hidden hover:shadow-none hover:translate-y-[4px] hover:bg-[#e1e3e5] cursor-pointer">
                            <div class="flex">

                                

                                
                                <div class="flex items-center">

                                    <i
                                        class="toggle-task-status md:text-xl text-sm <?php echo e($task->is_complete ? 'fa-regular fa-circle-check' : 'fa-regular fa-circle'); ?>"></i>
                                </div>

                                
                                <div class="flex ">
                                    <p class="title-task mx-3 md:text-base text-sm self-center font-medium duration-1000 capitalize transition-transform <?php echo e($task->is_complete ? 'line-through' : ''); ?>"
                                        data-task-id="<?php echo e($task->id); ?>">
                                        <?php echo e($task->title); ?></p>
                                </div>

                                
                                <div class="flex items-center ms-1.5">
                                    
                                    <?php if($task->priority === 'high'): ?>
                                        <span
                                            class="py-1 px-2 md:text-xs text-xs rounded-[4px] border-2 border-black bg-[#E53123] text-white">High</span>
                                    <?php elseif($task->priority === 'medium'): ?>
                                        <span
                                            class="py-1 px-2 md:text-xs text-xs rounded-[4px] border-2 border-black bg-[#efce31]">Medium</span>
                                    <?php elseif($task->priority === 'low'): ?>
                                        <span
                                            class="py-1 px-2 md:text-xs text-xs rounded-[4px] border-2 border-black text-white bg-[#3C6CCE]">Low</span>
                                    <?php endif; ?>
                                </div>
                                <div id="successLable" data-lable-id="<?php echo e($task->id); ?>"
                                    class="flex items-center ms-1.5 <?php echo e($task->is_complete ? '' : 'hidden'); ?>">
                                    <span
                                        class="py-1 px-2 md:text-xs text-xs rounded-[4px] border-2 border-black bg-[#50c881]">Success</span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
            <input id="current-task-id" type="hidden" class="text-black hidden" value=""></input>
            
            <div id="task-detail-container"
                class="md:row-start-2 row-start-3 min-h-[60vh] max-h-[calc(100vh-185px)] md:col-span-1 col-span-full overflow-y-auto scrollbar-thin scrollbar-thumb-black scrollbar-track-transparent scrollbar-thumb-rounded-full border-2 rounded-lg border-black shadow-[0px_6px_0px_0px_rgba(0,0,0,1)] me-0 mb-0 md:me-2 md:mb-2 bg-white">
                

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\todolist\resources\views/mytasks.blade.php ENDPATH**/ ?>